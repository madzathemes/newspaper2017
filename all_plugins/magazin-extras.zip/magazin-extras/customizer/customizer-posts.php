<?php
function magazin_customize_posts($wp_customize){

  Kirki::add_field( 'magazin_theme_options[category_grid_style]', array(
    'type'        => 'radio-image',
    'settings'    => 'magazin_theme_options[category_grid_style]',
    'label'       => esc_html__( 'Category Grid Style', 'magazin' ),
    'section'     => 'posts_default_settings',
    'default'     => '4',
    'option_type' => 'option',
    'priority'    => 20,
    'choices'     => array(
        '1'   => get_template_directory_uri() . '/inc/img/grid_style_1.png',
        '2' => get_template_directory_uri() . '/inc/img/grid_style_2.png',
        '3'   => get_template_directory_uri() . '/inc/img/grid_style_3.png',
        '4' => get_template_directory_uri() . '/inc/img/grid_style_4.png',
       ),
  ));

  Kirki::add_field( 'magazin_theme_options[category_post_style]', array(
    'type'        => 'radio-image',
    'settings'    => 'magazin_theme_options[category_post_style]',
    'label'       => esc_html__( 'Category Post Style', 'magazin' ),
    'section'     => 'posts_default_settings',
    'default'     => '4',
    'option_type' => 'option',
    'priority'    => 20,
    'choices'     => array(
        '1'   => get_template_directory_uri() . '/inc/img/c_post_style_1.png',
        '2' => get_template_directory_uri() . '/inc/img/c_post_style_2.png',
        '3'   => get_template_directory_uri() . '/inc/img/c_post_style_3.png',
        '4' => get_template_directory_uri() . '/inc/img/c_post_style_4.png',
       ),
  ));

} add_action('customize_register', 'magazin_customize_posts');

?>
